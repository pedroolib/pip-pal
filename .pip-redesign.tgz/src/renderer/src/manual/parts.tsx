import { useId, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Check, ChevronDown, Info, Lock, Pencil, Plus, Trash2 } from 'lucide-react'
import { Recipient, type Origin, type PendingEntry } from '@shared/schemas'
import { Badge } from '@renderer/components/ui/badge'
import { Button } from '@renderer/components/ui/button'
import { Card } from '@renderer/components/ui/card'
import { Checkbox } from '@renderer/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@renderer/components/ui/dialog'
import { Input } from '@renderer/components/ui/input'
import { Label } from '@renderer/components/ui/label'
import { Textarea } from '@renderer/components/ui/textarea'
import { DictateButton } from '@renderer/record/DictateButton'
import { cn } from '@renderer/lib/utils'
import { AliasField } from './AliasField'
import { aliasesToSave } from './model'

export type Kind = 'entry' | 'strategy' | 'person' | 'owner'
export type Draft = {
  text: string
  minutes: string
  name: string
  role: string
  aliases: string[]
  visibleTo: Recipient[]
}

const touch = 'min-h-10 min-w-11'

function Shared({ visibleTo }: { visibleTo: Recipient[] }): React.JSX.Element {
  const { t } = useTranslation()
  if (visibleTo.length === 0) {
    return (
      <Badge variant="outline" className="min-h-6 bg-muted text-sm">
        <Lock aria-hidden /> {t('manual.onlyYou')}
      </Badge>
    )
  }
  return (
    <>
      <span className="text-sm text-muted-foreground">{t('manual.sharedWith')}</span>
      {visibleTo.map((r) => (
        <Badge key={r} variant="secondary" className="min-h-6 text-sm">
          {t(`manual.recipients.${r}`)}
        </Badge>
      ))}
    </>
  )
}

function OriginBadge({ origin }: { origin: Origin }): React.JSX.Element {
  const { t } = useTranslation()
  return (
    <Badge variant="outline" className="min-h-6 text-sm">
      {origin !== 'self' && <span aria-hidden className="size-2 rounded-full bg-pip" />}
      {t(`manual.origin.${origin}`)}
    </Badge>
  )
}

/** A read-only row: content, origin, who can see it, edit and delete. `shared` is null for people. */
export function Row(props: {
  children: React.ReactNode
  origin?: Origin
  shared: Recipient[] | null
  what: string
  rowKey: string
  saved: boolean
  onEdit: () => void
  onDelete?: () => void
}): React.JSX.Element {
  const { t } = useTranslation()
  return (
    <li className="flex items-start gap-2 border-t px-5 py-4 first:border-t-0">
      <div className="min-w-0 flex-1">
        <div className="max-w-[62ch] leading-[1.6] text-foreground">{props.children}</div>
        {(props.shared || props.saved) && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {props.origin && props.shared && (
              <>
                <OriginBadge origin={props.origin} />
                <Shared visibleTo={props.shared} />
              </>
            )}
            {props.saved && (
              <span
                role="status"
                className="inline-flex items-center gap-1 text-sm font-bold text-primary"
              >
                <Check className="size-4" aria-hidden /> {t('manual.saved')}
              </span>
            )}
          </div>
        )}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className={touch}
        data-edit={props.rowKey}
        aria-label={t('manual.edit', { what: props.what })}
        onClick={props.onEdit}
      >
        <Pencil />
      </Button>
      {props.onDelete && (
        <Button
          variant="ghost"
          size="icon"
          className={touch}
          aria-label={t('manual.delete', { what: props.what })}
          onClick={props.onDelete}
        >
          <Trash2 />
        </Button>
      )}
    </li>
  )
}

function FieldError({
  id,
  children
}: {
  id: string
  children: React.ReactNode
}): React.JSX.Element {
  return (
    <div id={id} role="alert" className="flex items-center gap-2 text-sm font-bold text-primary">
      <Info className="size-4 shrink-0" aria-hidden /> {children}
    </div>
  )
}

/** Inline editor for an entry, strategy or person. One Save covers text and recipients. */
export function Editor(props: {
  kind: Kind
  title?: string
  initial?: Partial<Draft>
  onSave: (d: Draft) => Promise<boolean>
  onCancel: () => void
}): React.JSX.Element {
  const { t } = useTranslation()
  const uid = useId()
  const [d, setD] = useState<Draft>({
    text: '',
    minutes: '',
    name: '',
    role: '',
    aliases: [],
    visibleTo: [],
    ...props.initial
  })
  const [error, setError] = useState<'text' | 'minutes' | 'pair' | null>(null)
  const [failed, setFailed] = useState(false)
  const [pending, setPending] = useState('')
  const field = useRef<HTMLTextAreaElement>(null)
  const set = (p: Partial<Draft>): void => setD((x) => ({ ...x, ...p }))
  const minutes = Number(d.minutes)

  async function submit(e: React.FormEvent): Promise<void> {
    e.preventDefault()
    setFailed(false)
    if (props.kind === 'owner') {
      // nothing to validate: the list may be empty
    } else if (props.kind === 'person') {
      if (!d.name.trim() || !d.role.trim()) return setError('pair')
    } else if (!d.text.trim()) return setError('text')
    else if (props.kind === 'strategy' && !(Number.isInteger(minutes) && minutes >= 1))
      return setError('minutes')
    setError(null)
    // A part over the cap would be dropped on save: keep the form open on it (its message is already shown).
    const aliases = aliasesToSave(d.aliases, pending)
    if (!aliases) return document.getElementById(`${uid}-a`)?.focus()
    if (!(await props.onSave({ ...d, aliases }))) setFailed(true)
  }

  const err = (k: typeof error): object =>
    error === k ? { 'aria-invalid': true, 'aria-describedby': `${uid}-err` } : {}
  const message = {
    text: t('manual.validation'),
    minutes: t('manual.validationMinutes'),
    pair: t('manual.validationName')
  }

  return (
    <li className="min-w-0 border-t bg-background px-5 py-4 first:border-t-0">
      <form
        onSubmit={submit}
        onKeyDown={(e) => e.key === 'Escape' && props.onCancel()}
        className="grid min-w-0 gap-4"
        noValidate
      >
        <p className="text-sm text-muted-foreground">{t(`manual.editor.hint.${props.kind}`)}</p>
        {props.kind === 'owner' ? (
          <strong className="text-base">{props.title}</strong>
        ) : props.kind === 'person' ? (
          <div className="grid min-w-0 gap-4 sm:grid-cols-2">
            <div className="grid min-w-0 gap-2">
              <Label htmlFor={`${uid}-n`}>{t('manual.people.name')}</Label>
              <Input
                id={`${uid}-n`}
                autoFocus
                className="min-h-10 bg-surface"
                value={d.name}
                onChange={(e) => set({ name: e.target.value })}
                {...err('pair')}
              />
            </div>
            <div className="grid min-w-0 gap-2">
              <Label htmlFor={`${uid}-r`}>{t('manual.people.role')}</Label>
              <Input
                id={`${uid}-r`}
                className="min-h-10 bg-surface"
                value={d.role}
                onChange={(e) => set({ role: e.target.value })}
                {...err('pair')}
              />
            </div>
          </div>
        ) : props.kind === 'strategy' ? (
          <div className="grid min-w-0 gap-4 sm:grid-cols-[1fr_9rem]">
            <div className="grid min-w-0 gap-2">
              <Label htmlFor={`${uid}-t`}>{t('manual.calming.label')}</Label>
              <Input
                id={`${uid}-t`}
                autoFocus
                className="min-h-10 bg-surface"
                placeholder={t('manual.calming.placeholder')}
                value={d.text}
                onChange={(e) => set({ text: e.target.value })}
                {...err('text')}
              />
            </div>
            <div className="grid min-w-0 gap-2">
              <Label htmlFor={`${uid}-m`}>
                {t('manual.calming.minutes')} ({t('manual.calming.unit')})
              </Label>
              <Input
                id={`${uid}-m`}
                type="number"
                min={1}
                className="min-h-10 bg-surface"
                value={d.minutes}
                onChange={(e) => set({ minutes: e.target.value })}
                {...err('minutes')}
              />
            </div>
          </div>
        ) : (
          <div className="grid min-w-0 gap-2">
            <Label htmlFor={`${uid}-t`}>{t('manual.editor.entry')}</Label>
            <Textarea
              ref={field}
              id={`${uid}-t`}
              autoFocus
              className="min-h-24 bg-surface leading-[1.6]"
              value={d.text}
              onChange={(e) => set({ text: e.target.value })}
              {...err('text')}
            />
            <DictateButton field={field} onText={(v) => set({ text: v })} />
          </div>
        )}
        {(props.kind === 'person' || props.kind === 'owner') && (
          <AliasField
            id={`${uid}-a`}
            autoFocus={props.kind === 'owner'}
            hint={t(`manual.aliases.hint.${props.kind}`)}
            aliases={d.aliases}
            text={pending}
            onChange={(aliases, text) => {
              set({ aliases })
              setPending(text)
            }}
          />
        )}
        {error && <FieldError id={`${uid}-err`}>{message[error]}</FieldError>}

        {props.kind !== 'person' && props.kind !== 'owner' && (
          <fieldset className="grid gap-2">
            <legend className="text-sm font-bold">{t('manual.editor.whoCanSee')}</legend>
            <p className="text-sm text-muted-foreground">{t('manual.editor.leaveUnticked')}</p>
            <p className="text-sm text-muted-foreground">{t('manual.editor.sharingNote')}</p>
            <div className="flex flex-wrap gap-2">
              {Recipient.options.map((r) => (
                <Label
                  key={r}
                  htmlFor={`${uid}-${r}`}
                  className="min-h-10 cursor-pointer rounded-md border bg-surface px-3 text-base font-normal"
                >
                  <Checkbox
                    id={`${uid}-${r}`}
                    checked={d.visibleTo.includes(r)}
                    onCheckedChange={(on) =>
                      set({
                        visibleTo: on ? [...d.visibleTo, r] : d.visibleTo.filter((x) => x !== r)
                      })
                    }
                  />
                  {t(`manual.recipients.${r}`)}
                </Label>
              ))}
            </div>
          </fieldset>
        )}

        {failed && <FieldError id={`${uid}-fail`}>{t('manual.saveError')}</FieldError>}
        <div className="flex gap-2">
          <Button type="submit" className="min-h-10">
            {props.initial ? t('manual.save') : t(`manual.submitNew.${props.kind}`)}
          </Button>
          <Button type="button" variant="outline" className="min-h-10" onClick={props.onCancel}>
            {t('manual.cancel')}
          </Button>
        </div>
      </form>
    </li>
  )
}

export function ConfirmDelete(props: {
  open: boolean
  title: string
  quote: string
  keep: string
  confirm: string
  failed: boolean
  onKeep: () => void
  onConfirm: () => void
}): React.JSX.Element {
  const { t } = useTranslation()
  return (
    <Dialog open={props.open} onOpenChange={(o) => !o && props.onKeep()}>
      <DialogContent closeLabel={t('manual.close')}>
        <DialogHeader>
          <DialogTitle>{props.title}</DialogTitle>
          <DialogDescription>{t('manual.dialog.body')}</DialogDescription>
        </DialogHeader>
        <blockquote className="rounded-md bg-muted p-3 leading-[1.6]">{props.quote}</blockquote>
        {props.failed && <FieldError id="delete-fail">{t('manual.saveError')}</FieldError>}
        <DialogFooter className="flex-col sm:flex-row sm:justify-start">
          <Button className="min-h-10" autoFocus onClick={props.onKeep}>
            {props.keep}
          </Button>
          <Button variant="outline" className="min-h-10" onClick={props.onConfirm}>
            <Trash2 aria-hidden /> {props.confirm}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** What Pip noticed, waiting for a yes. Nothing here is used or shared until it is approved. */
export function PendingCard(props: {
  entries: PendingEntry[]
  onApprove: (id: string, text?: string) => Promise<boolean>
  onDismiss: (id: string) => Promise<boolean>
}): React.JSX.Element {
  const { t } = useTranslation()
  const uid = useId()
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState('')
  const field = useRef<HTMLTextAreaElement>(null)
  const [failed, setFailed] = useState<string | null>(null)
  const run = async (id: string, go: () => Promise<boolean>): Promise<void> => {
    const ok = await go()
    setFailed(ok ? null : id)
    if (ok) setEditing(null)
  }
  const pill = 'min-h-10 px-4 font-bold'
  return (
    <Card
      id="pending"
      aria-labelledby={`${uid}-h`}
      className="gap-0 overflow-hidden border-primary/25 bg-surface py-0"
    >
      <div className="px-5 pt-4 pb-2">
        <h2
          id={`${uid}-h`}
          data-pending-h
          tabIndex={-1}
          className="text-[1.0625rem] font-bold outline-none"
        >
          {t('manual.pending.title', { count: props.entries.length })}
        </h2>
        <p className="mt-1 max-w-[62ch] text-sm text-body">{t('manual.pending.note')}</p>
      </div>
      <ul>
        {props.entries.map((p) => (
          <li key={p.id} className="border-t px-5 py-4">
            <OriginBadge origin={p.origin} />
            {editing === p.id ? (
              <div className="mt-3 grid gap-2">
                <Label htmlFor={`${uid}-${p.id}`}>{t('manual.editor.entry')}</Label>
                <Textarea
                  ref={field}
                  id={`${uid}-${p.id}`}
                  autoFocus
                  className="min-h-24 bg-surface leading-[1.6]"
                  aria-describedby={failed === p.id ? `${uid}-${p.id}-e` : undefined}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                />
                <DictateButton field={field} onText={setDraft} />
              </div>
            ) : (
              <p className="mt-2 max-w-[62ch] leading-[1.6]">
                {p.minutes === undefined ? (
                  p.text
                ) : (
                  <>
                    <strong>{p.text}</strong>{' '}
                    <span className="whitespace-nowrap text-body">
                      {t('manual.calming.minutesShort', { count: p.minutes })}
                    </span>
                  </>
                )}
              </p>
            )}
            <p className="mt-1 text-sm text-muted-foreground">
              {t('manual.pending.why', { why: p.why })}
            </p>
            {failed === p.id && (
              <FieldError id={`${uid}-${p.id}-e`}>{t('manual.saveError')}</FieldError>
            )}
            <div className="mt-3 flex flex-wrap gap-2">
              {editing === p.id ? (
                <>
                  <Button
                    className={pill}
                    aria-describedby={failed === p.id ? `${uid}-${p.id}-e` : undefined}
                    disabled={!draft.trim()}
                    onClick={() => run(p.id, () => props.onApprove(p.id, draft))}
                  >
                    <Check aria-hidden /> {t('manual.pending.saveApprove')}
                  </Button>
                  <Button variant="outline" className={pill} onClick={() => setEditing(null)}>
                    {t('manual.cancel')}
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    className={pill}
                    aria-describedby={failed === p.id ? `${uid}-${p.id}-e` : undefined}
                    onClick={() => run(p.id, () => props.onApprove(p.id))}
                  >
                    <Check aria-hidden /> {t('manual.pending.approve')}
                  </Button>
                  <Button
                    variant="outline"
                    className={pill}
                    onClick={() => {
                      setDraft(p.text)
                      setEditing(p.id)
                    }}
                  >
                    <Pencil aria-hidden /> {t('manual.pending.edit')}
                  </Button>
                  <Button
                    variant="ghost"
                    className={pill}
                    aria-describedby={failed === p.id ? `${uid}-${p.id}-e` : undefined}
                    onClick={() => run(p.id, () => props.onDismiss(p.id))}
                  >
                    {t('manual.pending.dismiss')}
                  </Button>
                </>
              )}
            </div>
          </li>
        ))}
      </ul>
    </Card>
  )
}

/** A collapsible card: heading, count, optional note, rows, and an add button. */
export function Block(props: {
  id: string
  title: string
  count: string
  emptyText: string
  note?: string
  open: boolean
  onOpenChange: (o: boolean) => void
  empty: boolean
  formOpen: boolean
  addLabel: string
  onAdd: () => void
  children: React.ReactNode
}): React.JSX.Element {
  const footer = !props.formOpen && (
    <div className="border-t px-3 py-1">
      <Button variant="ghost" className="min-h-10 text-primary" onClick={props.onAdd}>
        <Plus aria-hidden /> {props.addLabel}
      </Button>
    </div>
  )
  return (
    <Card id={props.id} className="scroll-mt-12 gap-0 overflow-hidden bg-surface py-0">
      <div>
        <div className="flex items-center justify-between gap-2 px-5">
          <h2
            id={`${props.id}-h`}
            tabIndex={-1}
            className="min-w-0 flex-1 text-[1.0625rem] font-bold outline-none"
          >
            <button
              type="button"
              data-state={props.open ? 'open' : 'closed'}
              aria-expanded={props.open}
              aria-controls={`${props.id}-c`}
              onClick={() => props.onOpenChange(!props.open)}
              className="group flex min-h-10 w-full items-center gap-2 rounded-md text-left outline-none focus-visible:outline-2 focus-visible:outline-solid focus-visible:outline-ring"
            >
              <ChevronDown
                className="size-4 shrink-0 transition-transform duration-300 ease-(--ease-out) group-data-[state=closed]:-rotate-90"
                aria-hidden
              />
              {props.title}
            </button>
          </h2>
          {props.count && <span className="text-sm text-muted-foreground">{props.count}</span>}
        </div>
        {props.empty && (
          <p className="px-5 pb-3 pl-11 text-sm text-muted-foreground">{props.emptyText}</p>
        )}
        {props.empty && !props.open && footer}
        {/* Always mounted (inert while closed) so an open form keeps its draft while collapsed.
            The grid rows ease between 0fr and 1fr, so the section opens and closes smoothly. */}
        <div
          id={`${props.id}-c`}
          inert={!props.open}
          className={cn(
            'grid transition-[grid-template-rows,opacity] duration-300 ease-(--ease-out)',
            props.open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
          )}
        >
          <div className="min-h-0 overflow-hidden">
            {props.note && <p className="px-5 pb-3 pl-11 text-sm text-body">{props.note}</p>}
            <ul>{props.children}</ul>
            {footer}
          </div>
        </div>
      </div>
    </Card>
  )
}
